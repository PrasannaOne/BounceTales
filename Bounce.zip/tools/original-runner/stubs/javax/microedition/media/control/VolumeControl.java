package javax.microedition.media.control;
public interface VolumeControl extends javax.microedition.media.Control { int setLevel(int l); }
