# Bounce Tales V51 · responsive shell and startup-layout audit

**Release:** V51  
**Base:** V50  
**Gameplay scope:** no intentional changes to player physics, timing, level resources, original sprites, scripted events, or stage progression.

## 1. Findings addressed

### Fresh-device control flash

The touch-control elements are in the document before the application finishes loading the original game resources. The browser could therefore paint their legacy CSS grid positions before `applyLiveControlLayout()` supplied the shared geometry.

V51 applies the saved layout, or the canonical defaults when no saved layout exists, synchronously at the start of `boot()`, before the first asynchronous resource fetch. `applyControlLayoutToSurface()` now sets `data-layout-measured` only after every live control has its final left/top/width/height/min-height values. CSS keeps the control surface visually hidden until that marker is present. The existing resize observer and editor behavior remain active.

### Pause control placement

The pause control is no longer a child of the game viewport. The HTML now groups the pause gutter and canvas in `.game-stage`; the toolbar is placed before `#game-wrap`, aligns to the stage's right edge, and appears only while the game is in play mode. The button is 32 × 29 CSS pixels and has an explicit hidden-state rule so scene changes cannot accidentally override the HTML `hidden` attribute.

The stage wrapper is the responsive layout item in portrait and landscape layouts. That keeps the toolbar width identical to the game viewport instead of guessing a separate width and letting the edges drift apart.

## 2. CSS cascade audit

The stylesheet contains historical build sections because later releases introduced different shell layouts, viewport rules, wide-screen arrangements and touch-control geometry. A duplicate selector is not automatically dead: the same selector can intentionally have different values in separate media conditions, or a later declaration can complete an earlier rule without replacing all of its properties.

V51 removed three exact duplicate rule blocks that repeated the same selector, declarations and media condition. Other repeated selectors were retained where they contribute to the actual responsive cascade. The new V51 shell behavior is centralized in one final, clearly labeled block; no broad selector flattening or CSS minification was performed because that could change mobile/landscape precedence.

## 3. Cache and release identity

The HTML asset query strings use `v=51`, the service worker uses `bounce-tales-v51`, and the package version is `51.0.0`. The service-worker app shell uses the same versioned paths as the HTML document. The persistent touch-layout key remains `bounce-control-layout-v1`; existing saved arrangements are not discarded or migrated.

## 4. Protected behavior

The release does not intentionally modify:

- the 240 × 320 game coordinate system;
- the fixed-step simulation and movement/physics constants;
- the original RLEF campaign files and all 15 playable stages;
- springboard/trampoline behavior and its existing lifecycle proof;
- original sprite maps, dialogue resources, menu rendering or HUD drawing;
- progression data and the touch-control editor's storage format.

## 5. Automated verification

The release suite checks JavaScript syntax, the Node.js regression suite, runtime smoke behavior, all 15 stage load/play/pause routes in the smoke harness, and the dedicated Level 1 springboard lifecycle proof. New shell regressions check that the pause toolbar is between the site header and game canvas, that the first layout is applied before the initial asynchronous fetch, and that controls are not revealed before their positions and dimensions are written.

## 6. Compatibility boundaries

The project is a static browser application and does not require a bundler. The CSS includes viewport-unit fallbacks and responsive rules for portrait, landscape, compact and wide layouts. The runtime uses browser APIs such as Canvas, Fetch, Pointer Events, Web Audio, localStorage and service workers; service workers require HTTPS or localhost, and audio still follows each browser's user-gesture/autoplay policy.

Node.js checks do not constitute a physical-device or cross-browser certification. This environment did not run the app in Chromium, Safari, Firefox, Brave or WebView, and did not test a real phone. After deployment, verify first load and update from the prior service-worker cache on at least one iOS Safari device and one Android Chromium/Firefox-based browser, including portrait, landscape and a short viewport.

## 7. Result

V51 fixes the identified layout flash at its initialization boundary and moves the pause action to a small, non-overlapping top gutter. The remaining historical CSS blocks are intentionally retained where they carry active responsive behavior; only proven exact duplicates were removed.
