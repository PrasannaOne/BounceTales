(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports) module.exports=api;
  root.BouncePhysics=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';

  // Actor constants verified against c.class in the supplied Bounce Tales 2.0.3 JAR.
  // The public BounceObject decompilation is used only to make the obfuscated
  // stretch-rendering state readable; the supplied JAR remains the authority.
  const P=Object.freeze({
    radius:[20,20,20],
    gravity:[1.0,1.4,0.5],
    friction:[0.6,0.3,0.6],
    ricochet:[0.1,0.1,0.1],
    movementAcceleration:[500,350,312.5],
    maximumMovementSpeed:[280,350,150],
    midairSuppression:[1.5,2.5,1.2],
    jumpAcceleration:[288,255,162.5],
    maxJumpSlope:Math.cos(0.9599310755729675),
    baseGravityY:-400,
    maxVelocity:999,
    stretchLimit:70
  });

  const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
  const trunc32=v=>v|0;
  // Java `float` arithmetic is IEEE-754 binary32. Round after each source
  // float operation instead of allowing JS binary64 intermediates to drift.
  const f32=Math.fround;
  const fadd=(a,b)=>f32(f32(a)+f32(b));
  const fmul=(a,b)=>f32(f32(a)*f32(b));

  class BounceBody{
    constructor(x=0,y=0,unlockedForme=0){
      this.x=x;this.y=y;this.x16=(Math.trunc(x*65536)|0);this.y16=(Math.trunc(y*65536)|0);
      this.prevX=x;this.prevY=y;this.vx=0;this.vy=0;this.lastVx=0;this.lastVy=0;
      this.gravityX=0;this.gravityY=0;this.pushX=0;this.pushY=0;
      this.torqueX=0;this.torqueY=0;this.forme=0;this.unlockedForme=unlockedForme;
      this.grounded=false;this.slopeSinAbs=0;this.slopeCosAbs=1;this.airTime=0;
      this.enabled=true;this.rotation=0;this.curVelocity=0;
      this.radius=P.radius[0];
      // These are the four directional spring/stretch accumulators in c.class.
      this.reqStretch=[0,0,0,0];
      this.stretchMagnitude=[0,0,0,0];
      this.stretchResult=[0,0,0,0];
      this.stretchResultAbs=[0,0,0,0];
      this.stretchDirBalance=[0,0,0,0];
      this.stretchBuffer=[999,999,999,999];
      this.eyeFrame=0;this.idleAnimTimer=0;this.idleAnimStartTimer=3000;
      this.skipAccelStretch=false;
    }
    reset(x,y){
      this.x=x;this.y=y;this.x16=(Math.trunc(x*65536)|0);this.y16=(Math.trunc(y*65536)|0);
      this.prevX=x;this.prevY=y;this.vx=0;this.vy=0;this.lastVx=0;this.lastVy=0;
      this.gravityX=0;this.gravityY=0;this.pushX=0;this.pushY=0;
      this.torqueX=0;this.torqueY=0;this.grounded=false;this.airTime=0;
      this.curVelocity=0;this.rotation=0;this.eyeFrame=0;this.idleAnimTimer=0;
      this.idleAnimStartTimer=3000;this.skipAccelStretch=true;
      this.reqStretch.fill(0);this.stretchMagnitude.fill(0);
      this.stretchResult.fill(0);this.stretchResultAbs.fill(0);
      this.stretchDirBalance.fill(0);this.stretchBuffer.fill(999);
    }
    snapRenderPosition(){
      this.prevX=this.x;
      this.prevY=this.y;
    }
    requestStretch(dir,magnitude){
      magnitude=clamp(Math.trunc(magnitude),-P.stretchLimit,P.stretchLimit);
      if(magnitude)this.reqStretch[dir]+=magnitude;
    }
    moveLeft(superBounce=false){
      const mode=this.forme,speedBoost=superBounce&&mode===0?50:0;
      if(this.grounded){
        if(this.vx>(-P.maximumMovementSpeed[mode])-speedBoost)this.gravityX-=speedBoost+P.movementAcceleration[mode];
      }else if(this.vx>(-P.maximumMovementSpeed[mode])-speedBoost){
        this.gravityX-=(speedBoost+P.movementAcceleration[mode])/P.midairSuppression[mode];
      }
    }
    moveRight(superBounce=false){
      const mode=this.forme,speedBoost=superBounce&&mode===0?50:0;
      if(this.grounded){
        if(this.vx<P.maximumMovementSpeed[mode]+speedBoost)this.gravityX+=speedBoost+P.movementAcceleration[mode];
      }else if(this.vx<P.maximumMovementSpeed[mode]+speedBoost){
        this.gravityX+=(speedBoost+P.movementAcceleration[mode])/P.midairSuppression[mode];
      }
    }
    jump(small=false){
      if(this.slopeCosAbs>P.maxJumpSlope&&this.grounded){
        this.pushY+=small?P.jumpAcceleration[this.forme]/2:P.jumpAcceleration[this.forme];
        this.grounded=false;
        this.requestStretch(0,small?-27:-53);
        this.requestStretch(1,small?-27:-53);
      }
    }
    cycleForme(){
      this.forme++;
      if(this.forme>2)this.forme=0;
      if(this.forme>this.unlockedForme)this.forme=0;
      this.radius=P.radius[this.forme];
      return this.forme;
    }
    update(dt,screenScale=0.660187,sourceDeltaMs=null){
      if(!this.enabled||!(dt>0))return;
      // Keep the original actor transform in signed 16.16 LP32 coordinates.
      // Velocities and accelerations remain Java-float equivalents, as in c.class.
      if(this.x!==this.x16/65536)this.x16=(Math.trunc(this.x*65536)|0);
      if(this.y!==this.y16/65536)this.y16=(Math.trunc(this.y*65536)|0);
      this.prevX=this.x;this.prevY=this.y;
      const updateDelta=Math.max(1,Math.trunc(sourceDeltaMs??(dt*1000)));
      const mode=this.forme;
      // c.d(): var11 = (float)o.a * 0.001F; var3 = 1.0F / a[forme].
      // o.a is the integer elapsed-millisecond tick supplied by the MIDP loop.
      const motionDelta=fmul(updateDelta,0.001);
      const gravityScale=f32(P.gravity[mode]);
      const invGravity=f32(1.0/gravityScale);

      // Exact acceleration-to-stretch request mapping from the JAR's update method.
      if(!this.skipAccelStretch){
        const xaccel=this.vx-this.lastVx,yaccel=this.vy-this.lastVy;
        if(xaccel>0)this.requestStretch(3,(((Math.trunc(xaccel)>>2)<<1)/3)|0);
        else this.requestStretch(2,((((-Math.trunc(xaccel))>>2)<<1)/3)|0);
        if(yaccel>0)this.requestStretch(1,(((Math.trunc(yaccel)>>2)<<1)/3)|0);
        else this.requestStretch(0,((((-Math.trunc(yaccel))>>2)<<1)/3)|0);
      }
      this.skipAccelStretch=false;

      // Direct c.d() port, preserving Java float evaluation order:
      // d += 0*a[forme]; e += (-400)*a[forme];
      // velocity += (acceleration * (1/a[forme])) * (o.a * 0.001F);
      // velocity += impulse * (1/a[forme]);
      this.lastVx=f32(this.vx);this.lastVy=f32(this.vy);
      this.gravityX=fadd(this.gravityX,fmul(0,gravityScale));
      this.gravityY=fadd(this.gravityY,fmul(P.baseGravityY,gravityScale));
      this.vx=fadd(this.vx,fmul(fmul(this.gravityX,invGravity),motionDelta));
      this.vy=fadd(this.vy,fmul(fmul(this.gravityY,invGravity),motionDelta));
      this.vx=fadd(this.vx,fmul(this.pushX,invGravity));
      this.vy=fadd(this.vy,fmul(this.pushY,invGravity));
      // Java `(int)(velocity * var11 * 65536.0F)` truncates toward zero.
      this.x16=(this.x16+Math.trunc(fmul(fmul(this.vx,motionDelta),65536.0)))|0;
      this.y16=(this.y16+Math.trunc(fmul(fmul(this.vy,motionDelta),65536.0)))|0;
      this.x=this.x16/65536;this.y=this.y16/65536;
      this.gravityX=0;this.gravityY=0;this.pushX=0;this.pushY=0;

      // The original uses collision-produced torque projected onto the current surface slope.
      const f7=this.torqueX*this.slopeSinAbs+this.torqueY*this.slopeCosAbs;
      let f=this.torqueX-this.slopeSinAbs*f7;
      let f2=this.torqueY-this.slopeCosAbs*f7;
      if(this.slopeSinAbs*this.torqueX+this.slopeCosAbs*this.torqueY<0){
        f=this.torqueX+this.slopeSinAbs*f7;
        f2=this.torqueY+this.slopeCosAbs*f7;
      }
      const turn=motionDelta*(Math.hypot(f,f2)/P.radius[mode]);
      this.rotation+=((f2*this.slopeSinAbs)-(f*this.slopeCosAbs)>0?-turn:turn);

      this.airTime+=motionDelta;
      if(this.airTime>0.25)this.grounded=false;
      this.curVelocity=Math.hypot(this.vx,this.vy);
      if(this.curVelocity>P.maxVelocity){
        const inv=P.maxVelocity/this.curVelocity;this.vx*=inv;this.vy*=inv;this.curVelocity=P.maxVelocity;
      }

      // Source-faithful 16.16 spring calculations from the original actor update.
      const scale16=Math.round(screenScale*65536);
      for(let axis=0;axis<4;axis++){
        this.stretchMagnitude[axis]=trunc32(this.stretchMagnitude[axis]+this.reqStretch[axis]*65536);
        this.reqStretch[axis]=0;
        this.stretchMagnitude[axis]=clamp(this.stretchMagnitude[axis],-70*65536,70*65536)|0;
        this.stretchResult[axis]=Math.imul(1,this.stretchResult[axis]+Math.imul(this.stretchMagnitude[axis],updateDelta));
        this.stretchResultAbs[axis]=Math.imul((this.stretchResult[axis]>>16),scale16)>>16;
        // The original class promotes these products to Java long before shifting.
        // Keep the products in JS Number precision, then apply a signed arithmetic
        // shift equivalent (floor division by 2^16). Math.imul here would overflow.
        const restoring=Math.floor((updateDelta*7*(-this.stretchResult[axis]))/65536);
        const damping=Math.floor((updateDelta*120*this.stretchMagnitude[axis])/65536);
        this.stretchMagnitude[axis]=trunc32(this.stretchMagnitude[axis]+restoring-damping);
      }
    }
    land(nx,ny,dt,preCollisionVelocity=null){
      const n=Math.hypot(nx,ny)||1;nx/=n;ny/=n;
      const before=preCollisionVelocity||{x:this.vx,y:this.vy};
      const incomingX=Number.isFinite(before.x)?before.x:this.vx;
      const incomingY=Number.isFinite(before.y)?before.y:this.vy;
      this.slopeSinAbs=nx;this.slopeCosAbs=ny;this.airTime=0;this.grounded=true;

      // Port of the JAR's collision response: reflect the incoming normal
      // component with the current form's restitution, then use the velocity
      // delta to choose between the required stopping acceleration and the
      // friction force produced by gravity along this surface.
      const vn=incomingX*nx+incomingY*ny;
      this.vx=incomingX;this.vy=incomingY;
      if(vn<0){const e=P.ricochet[this.forme];this.vx-=(1+e)*vn*nx;this.vy-=(1+e)*vn*ny;}
      const dvx=this.vx-incomingX,dvy=this.vy-incomingY;
      if(dt>1e-6){
        const gravity=P.gravity[this.forme],inverseDelta=1/dt;
        const requiredX=dvx*inverseDelta*gravity,requiredY=dvy*inverseDelta*gravity;
        const changeSpeed=Math.hypot(dvx,dvy);
        const frictionForce=(-P.baseGravityY*ny)*P.friction[this.forme]*gravity;
        const frictionX=changeSpeed>1e-7?(dvx/changeSpeed)*frictionForce:0;
        const frictionY=changeSpeed>1e-7?(dvy/changeSpeed)*frictionForce:0;
        if(requiredX*requiredX+requiredY*requiredY<frictionX*frictionX+frictionY*frictionY){
          this.gravityX-=requiredX;this.gravityY-=requiredY;
        }else{
          this.gravityX-=frictionX;this.gravityY-=frictionY;
        }
      }
      this.torqueX=this.torqueX*.5+dvx*.5;
      this.torqueY=this.torqueY*.5+dvy*.5;
    }
    syncFixedPosition(){
      this.x16=(Math.trunc(this.x*65536)|0);this.y16=(Math.trunc(this.y*65536)|0);
      this.x=this.x16/65536;this.y=this.y16/65536;
    }
    resetPhysics(){
      this.vx=this.vy=this.gravityX=this.gravityY=this.pushX=this.pushY=this.torqueX=this.torqueY=0;
      this.curVelocity=0;this.airTime=0;this.grounded=false;
    }
    get stretch(){
      const balance=[0,0,0,0];
      for(let a=0;a<4;a++)for(let b=0;b<4;b++)if(a!==b)balance[a]-=this.stretchResultAbs[b]>>1;
      this.stretchDirBalance=balance;
      return {resultAbs:this.stretchResultAbs,balance,buffer:this.stretchBuffer};
    }
    static get parameters(){return P;}
  }
  return {BounceBody,parameters:P};
});
