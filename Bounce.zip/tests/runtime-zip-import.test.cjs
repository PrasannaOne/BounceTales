'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'bounce-zip-test-'));
const importer = path.join(root, 'tools/import_runtime_zip.py');

function run(archive, destination = temp, validateOnly = true) {
  const args = [importer, archive, destination];
  if (validateOnly) args.push('--validate-only');
  return spawnSync('python3', args, { cwd: root, encoding: 'utf8' });
}
function makeZip(target, version = 55, extra = {}) {
  const py = String.raw`
import json, sys, zipfile
p, version = sys.argv[1], int(sys.argv[2])
extra = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
files = {
 'index.html': f'<!doctype html><link rel="stylesheet" href="style.css?v={version}"><script src="game.js?v={version}"></script><script src="sw.js?v={version}"></script>',
 'style.css': 'body{}', 'game.js': '/* runtime */',
 'sw.js': "const CACHE_NAME = 'bounce-tales-v{}'; const APP_SHELL = ".format(version) + json.dumps(['./', 'index.html', f'style.css?v={version}', f'game.js?v={version}', 'assets/original/bu', f'src/control-layout.js?v={version}']) + ';',
 'manifest.webmanifest': json.dumps({'icons':[{'src':'favicon.png'}]}),
 'favicon.png':'icon', 'icon-192.png':'icon', 'icon-512.png':'icon', 'apple-touch-icon.png':'icon',
 'bounce-tales-web-preview.png':'preview',
 'assets/original/bu':'cannon', 'src/control-layout.js':'module'
}
with zipfile.ZipFile(p, 'w') as z:
 z.writestr('assets/', '')
 z.writestr('assets/original/', '')
 z.writestr('src/', '')
 for name, data in files.items(): z.writestr(name, data)
 for name, data in extra.get('test_files', {}).items(): z.writestr('tests/' + name, data)
`;
  const result = spawnSync('python3', ['-c', py, target, String(version), JSON.stringify(extra)], { encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr || result.stdout);
}

try {
  const valid = path.join(temp, 'valid-v58.zip');
  makeZip(valid, 58);
  const validResult = run(valid);
  assert.equal(validResult.status, 0, validResult.stderr || validResult.stdout);
  assert.match(validResult.stdout, /ZIP validation passed/);

  // The importer accepts older or newer release numbers when internal cache references agree.
  const older = path.join(temp, 'older-v1.zip');
  makeZip(older, 1);
  const olderResult = run(older);
  assert.equal(olderResult.status, 0, olderResult.stderr || olderResult.stdout);

  const mismatch = path.join(temp, 'mismatched-version.zip');
  makeZip(mismatch, 58);
  const change = spawnSync('python3', ['-c', String.raw`
import sys, zipfile
source, target = sys.argv[1:]
with zipfile.ZipFile(source) as src, zipfile.ZipFile(target, 'w') as dst:
 for item in src.infolist():
  data = src.read(item.filename)
  if item.filename == 'index.html': data = data.replace(b'v=58', b'v=54', 1)
  dst.writestr(item, data)
`, valid, mismatch], { encoding: 'utf8' });
  assert.equal(change.status, 0, change.stderr);
  const mismatchResult = run(mismatch);
  assert.notEqual(mismatchResult.status, 0, 'inconsistent HTML and worker versions must be rejected');
  assert.match(mismatchResult.stderr, /Inconsistent runtime version/);

  const traversal = path.join(temp, 'traversal.zip');
  const badPath = spawnSync('python3', ['-c', String.raw`
import sys, zipfile
with zipfile.ZipFile(sys.argv[1], 'w') as z: z.writestr('../escape.txt', 'nope')
`, traversal], { encoding: 'utf8' });
  assert.equal(badPath.status, 0, badPath.stderr);
  const traversalResult = run(traversal);
  assert.notEqual(traversalResult.status, 0, 'path traversal archive must be rejected');
  assert.match(traversalResult.stderr, /Unsafe ZIP path segment/);

  const symlink = path.join(temp, 'symlink.zip');
  const badLink = spawnSync('python3', ['-c', String.raw`
import sys, zipfile
z=zipfile.ZipFile(sys.argv[1], 'w')
i=zipfile.ZipInfo('link'); i.create_system=3; i.external_attr=(0o120777 << 16); z.writestr(i, '/etc/passwd'); z.close()
`, symlink], { encoding: 'utf8' });
  assert.equal(badLink.status, 0, badLink.stderr);
  const symlinkResult = run(symlink);
  assert.notEqual(symlinkResult.status, 0, 'symlink archive must be rejected');
  assert.match(symlinkResult.stderr, /symlinks are not allowed|Special files/);

  // Importing a test-free runtime must leave the repository's existing suite untouched.
  const importZip = path.join(temp, 'import-no-tests.zip');
  makeZip(importZip, 57);
  const destination = path.join(temp, 'repo');
  fs.mkdirSync(path.join(destination, 'tests'), { recursive: true });
  fs.mkdirSync(path.join(destination, 'assets'), { recursive: true });
  fs.writeFileSync(path.join(destination, 'tests', 'keep-me.test.cjs'), '// repository-owned test');
  fs.writeFileSync(path.join(destination, 'package.json'), JSON.stringify({ name: 'bounce-tales', version: '1.0.0' }));
  const imported = run(importZip, destination, false);
  assert.equal(imported.status, 0, imported.stderr || imported.stdout);
  assert.equal(fs.readFileSync(path.join(destination, 'tests', 'keep-me.test.cjs'), 'utf8'), '// repository-owned test');
  assert.equal(fs.existsSync(path.join(destination, 'tests', 'sample.test.cjs')), false);
  assert.equal(JSON.parse(fs.readFileSync(path.join(destination, 'package.json'), 'utf8')).version, '57.0.0');
  assert.equal(fs.readFileSync(path.join(destination, 'assets', 'original', 'bu'), 'utf8'), 'cannon');
  assert.equal(fs.existsSync(importZip), false, 'successful import removes the upload archive');

  // Versioned test files update by exact filename; repository-only tests and records survive.
  const mergeZip = path.join(temp, 'merge-tests-v58.zip');
  makeZip(mergeZip, 58, { test_files: {
    'keep-me.test.cjs': '// updated by V58',
    'new-v58.test.cjs': '// added by V58'
  }});
  const mergeDestination = path.join(temp, 'merge-repository');
  fs.mkdirSync(path.join(mergeDestination, 'tests'), { recursive: true });
  fs.mkdirSync(path.join(mergeDestination, 'docs'), { recursive: true });
  fs.writeFileSync(path.join(mergeDestination, 'tests', 'keep-me.test.cjs'), '// old repository test');
  fs.writeFileSync(path.join(mergeDestination, 'tests', 'custom-remote.test.cjs'), '// remote-only test');
  fs.writeFileSync(path.join(mergeDestination, 'README.md'), '# Preserve this README');
  fs.writeFileSync(path.join(mergeDestination, 'LICENSE'), 'preserve licence');
  fs.writeFileSync(path.join(mergeDestination, 'docs', 'sentinel.md'), 'preserve docs');
  fs.writeFileSync(path.join(mergeDestination, '.workflow-sentinel'), 'preserve workflow metadata');
  fs.writeFileSync(path.join(mergeDestination, 'package.json'), JSON.stringify({ name: 'bounce-tales', version: '53.0.0' }));
  const merged = run(mergeZip, mergeDestination, false);
  assert.equal(merged.status, 0, merged.stderr || merged.stdout);
  assert.equal(fs.readFileSync(path.join(mergeDestination, 'tests', 'keep-me.test.cjs'), 'utf8'), '// updated by V58');
  assert.equal(fs.readFileSync(path.join(mergeDestination, 'tests', 'new-v58.test.cjs'), 'utf8'), '// added by V58');
  assert.equal(fs.readFileSync(path.join(mergeDestination, 'tests', 'custom-remote.test.cjs'), 'utf8'), '// remote-only test');
  assert.equal(fs.readFileSync(path.join(mergeDestination, 'README.md'), 'utf8'), '# Preserve this README');
  assert.equal(fs.readFileSync(path.join(mergeDestination, 'LICENSE'), 'utf8'), 'preserve licence');
  assert.equal(fs.readFileSync(path.join(mergeDestination, 'docs', 'sentinel.md'), 'utf8'), 'preserve docs');
  assert.equal(fs.readFileSync(path.join(mergeDestination, '.workflow-sentinel'), 'utf8'), 'preserve workflow metadata');
  assert.equal(JSON.parse(fs.readFileSync(path.join(mergeDestination, 'package.json'), 'utf8')).version, '58.0.0');
  assert.match(merged.stdout, /merged 2 test file/);
  assert.equal(fs.existsSync(mergeZip), false, 'successful merge removes the upload archive');

  console.log('Runtime ZIP importer: version-agnostic validation, test-free ZIPs, non-destructive same-name test merge, preservation of remote-only tests and project records, version consistency, traversal and symlink protections passed');
} finally {
  fs.rmSync(temp, { recursive: true, force: true });
}
