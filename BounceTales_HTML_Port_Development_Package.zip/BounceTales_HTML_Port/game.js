/*
 * Bounce Tales HTML port development shell.
 * Original assets are kept unchanged in assets/original/.
 * The Java ME gameplay engine is not yet translated.
 */
(() => {
  'use strict';
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d', { alpha: false });
  const saveKey = 'bounceTales.port.save.v1';
  const saveLabel = document.getElementById('save-state');
  const save = loadSave();
  const logo = new Image();
  let logoReady = false;

  function loadSave() {
    try {
      const value = JSON.parse(localStorage.getItem(saveKey) || 'null');
      if (value && value.version === 1) return value;
    } catch (error) {
      console.warn('Could not read local save:', error);
    }
    return { version: 1, progress: {}, settings: { sound: true } };
  }

  function persist() {
    try {
      localStorage.setItem(saveKey, JSON.stringify(save));
      saveLabel.textContent = 'Local save available on this device';
    } catch (error) {
      saveLabel.textContent = 'Local storage unavailable';
      console.warn('Could not save:', error);
    }
  }

  function drawShell() {
    ctx.fillStyle = '#08080d';
    ctx.fillRect(0, 0, 240, 320);
    if (logoReady) {
      const width = 168, height = 121;
      ctx.drawImage(logo, (240 - width) / 2, 52, width, height);
    } else {
      ctx.fillStyle = '#f4effa';
      ctx.textAlign = 'center';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('BOUNCE TALES', 120, 116);
    }
    ctx.textAlign = 'center';
    ctx.fillStyle = '#d8cbe5';
    ctx.font = 'bold 10px sans-serif';
    ctx.fillText('HTML PORT DEVELOPMENT BUILD', 120, 212);
    ctx.fillStyle = '#a99ebd';
    ctx.font = '9px sans-serif';
    ctx.fillText('Original assets verified', 120, 234);
    ctx.fillText('Gameplay engine still being translated', 120, 249);
    ctx.fillStyle = '#59486c';
    ctx.fillRect(42, 267, 156, 1);
    ctx.fillStyle = '#8e80a0';
    ctx.font = '8px sans-serif';
    ctx.fillText('240 × 320 LOGICAL DISPLAY', 120, 284);
  }

  logo.onload = () => { logoReady = true; drawShell(); };
  logo.onerror = () => drawShell();
  logo.src = 'assets/original/j.png';
  drawShell();

  function sendKey(name, down) {
    window.dispatchEvent(new CustomEvent('midpkey', { detail: { key: name, down } }));
  }

  document.querySelectorAll('[data-key]').forEach(button => {
    const key = button.dataset.key;
    button.addEventListener('pointerdown', event => {
      event.preventDefault();
      button.setPointerCapture?.(event.pointerId);
      sendKey(key, true);
    });
    for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
      button.addEventListener(type, () => sendKey(key, false));
    }
    button.addEventListener('contextmenu', event => event.preventDefault());
  });

  const keyboardMap = {
    ArrowLeft: 'LEFT', ArrowRight: 'RIGHT', ArrowUp: 'UP', ArrowDown: 'DOWN',
    Enter: 'SELECT', Escape: 'BACK', Backspace: 'BACK', ' ': 'FIRE',
    '*': 'SOFT_LEFT', '#': 'SOFT_RIGHT'
  };
  document.addEventListener('keydown', event => {
    const key = keyboardMap[event.key];
    if (key) { event.preventDefault(); sendKey(key, true); }
  });
  document.addEventListener('keyup', event => {
    const key = keyboardMap[event.key];
    if (key) { event.preventDefault(); sendKey(key, false); }
  });

  document.getElementById('reset-save').addEventListener('click', () => {
    if (!window.confirm('Delete this device’s Bounce Tales port save?')) return;
    try { localStorage.removeItem(saveKey); } catch (error) { console.warn(error); }
    save.progress = {};
    save.settings = { sound: true };
    persist();
  });
  persist();
})();
