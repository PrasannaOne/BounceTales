# Port status

## Verified from the supplied JAR

- MIDlet: `RMIDlet`, version 2.0.3.
- Platform metadata: CLDC 1.1 / MIDP 2.0, with Nokia platform extensions.
- Original logical display target selected for this port shell: 240×320.
- 19 class files and 106 total archive files extracted.
- All 106 extracted files were compared with the supplied JAR and matched byte-for-byte.
- Original image and audio files are preserved; no image has been redrawn or recompressed.

## Not yet ported

- Full title/menu flow and menu selection behaviour.
- Player movement, acceleration, bouncing, gravity, collision and damage/death rules.
- Level loading, tile/object decoding, triggers, checkpoints and level progression.
- Sprite animation timing and effects.
- MIDI selection, playback timing and sound effects.
- Original settings, progress persistence and save compatibility.
- End-to-end comparison against the original handset/emulator output.

## Acceptance checklist for a genuine one-to-one port

- [ ] Boot/menu sequence and all menus match.
- [ ] Each key mapping matches original controls.
- [ ] Player movement and collision are frame-accurate within the chosen 240×320 timing model.
- [ ] Every level, object, enemy, trigger and checkpoint has been checked.
- [ ] Sprite frames, transitions and draw ordering match.
- [ ] Music and sound events are mapped to the correct original tracks.
- [ ] Save/load, pause/resume and restart match original behaviour.
- [ ] Tested on Android browsers at multiple viewport sizes.

A build should only be labelled **one-to-one** after this checklist has been exercised against the original game.
