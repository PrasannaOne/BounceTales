# Bounce Tales HTML Port — development package

This is the **source/resource package for the port**, not a completed playable conversion yet. It does not embed an emulator, run the Java ME JAR, or use a Java runtime.

## What is included

- All **106 files** extracted from the supplied JAR, byte-for-byte unchanged, under `assets/original/` (47 PNGs, 8 MIDI tracks, class files, language files, and game data).
- The original 240×320 logical canvas and Android-friendly touch controls.
- Keyboard/touch input events prepared for the translated game engine.
- A local-storage save foundation.
- `reverse-engineering/bytecode/`: `javap` bytecode listings for all 19 classes.
- Asset inventory and reverse-engineering notes.

## Important status

The original Java classes are obfuscated. The runtime, game-state controller, player physics, collision rules, level/data parsers, animations, audio triggers, menus and save format still need to be translated and tested. **This package is not yet the one-to-one playable port.** The visible screen is deliberately labelled as a development build rather than pretending otherwise.

## Upload to GitHub Pages

1. Extract this ZIP and upload its contents to the root of your GitHub repository.
2. In the repository, create `.github/workflows/`.
3. Upload the separately supplied `BounceTales_Pages_Deploy.yml` into that folder and rename it to `pages.yml`. The final path must be `.github/workflows/pages.yml`.
4. In **Settings → Pages**, set the source to **GitHub Actions**.
5. Push to the `main` branch, or run the workflow manually from the Actions tab.

The project is a static website and does not need a server or secrets.
